import { Observable, ImageSource } from '@nativescript/core';
import { NutritionService } from '../../services/nutrition.service';
import { DiaryService } from '../../services/diary.service';
import { FoodItem } from '../../models/nutrition.model';
import { takePicture, requestPermissions } from '@nativescript/camera';

export class ScanViewModel extends Observable {
  private nutritionService: NutritionService;
  private diaryService: DiaryService;
  
  constructor() {
    super();
    this.nutritionService = new NutritionService();
    this.diaryService = DiaryService.getInstance();
    this.set('analyzing', false);
    this.set('foodInfo', null);
  }

  async onTakePhoto() {
    try {
      const permission = await requestPermissions();
      if (!permission) {
        // Handle permission denied
        return;
      }

      const imageAsset = await takePicture({
        width: 1024,
        height: 1024,
        keepAspectRatio: true,
        saveToGallery: false
      });

      if (imageAsset) {
        const imageSource = await ImageSource.fromAsset(imageAsset);
        this.set('previewImage', imageSource);
        await this.analyzeFood(imageSource);
      }
    } catch (error) {
      console.error('Error taking photo:', error);
      // Show error message to user
    }
  }

  async onSelectPhoto() {
    // Implementation for selecting photo from gallery
    // This would use a photo picker plugin
    this.analyzeFood(null);
  }

  private async analyzeFood(imageSource: any) {
    try {
      this.set('analyzing', true);
      const foodInfo = await this.nutritionService.analyzeFoodImage(imageSource);
      this.set('foodInfo', foodInfo);
    } catch (error) {
      console.error('Error analyzing food:', error);
      // Show error message to user
    } finally {
      this.set('analyzing', false);
    }
  }

  onLogFood() {
    const foodInfo = this.get('foodInfo');
    if (foodInfo) {
      this.diaryService.addEntry({
        id: Date.now().toString(),
        timestamp: new Date(),
        foodItem: foodInfo.name,
        portion: foodInfo.portion,
        calories: foodInfo.nutrition.calories,
        protein: foodInfo.nutrition.protein,
        carbs: foodInfo.nutrition.carbs,
        fat: foodInfo.nutrition.fat
      });
      
      // Reset the scan view
      this.set('foodInfo', null);
      this.set('previewImage', null);
    }
  }
}