import { Observable } from '@nativescript/core';
import { DiaryService } from '../../services/diary.service';
import { DailyLog } from '../../models/diary.model';

export class DiaryViewModel extends Observable {
  private diaryService: DiaryService;
  private currentDateValue: Date;

  constructor() {
    super();
    this.diaryService = DiaryService.getInstance();
    this.currentDateValue = new Date();
    this.loadCurrentDay();
  }

  get currentDate(): string {
    return this.currentDateValue.toLocaleDateString();
  }

  onPreviousDay() {
    this.currentDateValue.setDate(this.currentDateValue.getDate() - 1);
    this.loadCurrentDay();
  }

  onNextDay() {
    this.currentDateValue.setDate(this.currentDateValue.getDate() + 1);
    this.loadCurrentDay();
  }

  private loadCurrentDay() {
    const dailyLog = this.diaryService.getDailyLog(this.currentDateValue);
    this.set('currentDate', this.currentDate);
    this.set('dailyLog', dailyLog);
  }
}