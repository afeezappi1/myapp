import { Observable } from '@nativescript/core';
import { User } from '../../models/user.model';

export class ProfileViewModel extends Observable {
  private user: User;

  constructor() {
    super();
    this.user = User.getInstance();
    this.initializeData();
  }

  private initializeData() {
    const profile = this.user.profile;
    this.set('name', profile.name);
    this.set('age', profile.age);
    this.set('height', profile.height);
    this.set('weight', profile.weight);
    this.set('genderIndex', this.getGenderIndex(profile.gender));
    this.set('dietaryPreferences', [
      { name: 'Vegetarian', selected: false },
      { name: 'Vegan', selected: false },
      { name: 'Gluten-Free', selected: false },
      { name: 'Low-Carb', selected: false },
      { name: 'Dairy-Free', selected: false }
    ]);
  }

  private getGenderIndex(gender: string): number {
    const genders = ['male', 'female', 'other'];
    return genders.indexOf(gender.toLowerCase());
  }

  onSaveProfile() {
    const updatedProfile = {
      name: this.get('name'),
      age: parseInt(this.get('age')),
      height: parseInt(this.get('height')),
      weight: parseInt(this.get('weight')),
      gender: ['male', 'female', 'other'][this.get('genderIndex')],
      dietaryPreferences: this.get('dietaryPreferences')
        .filter(pref => pref.selected)
        .map(pref => pref.name)
    };

    this.user.updateProfile(updatedProfile);
    // Show success message or navigate back
  }
}