import { FoodItem, NutritionInfo } from '../models/nutrition.model';

export class NutritionService {
  analyzeFoodImage(imageSource: any): Promise<FoodItem> {
    // Mock implementation - In real app, this would use ML/AI
    return Promise.resolve({
      name: 'Sample Food',
      portion: '100g',
      nutrition: {
        calories: 250,
        protein: 12,
        carbs: 30,
        fat: 8,
        fiber: 4,
        vitamins: {},
        minerals: {},
        allergens: []
      },
      ingredients: ['ingredient1', 'ingredient2'],
      category: 'main_dish'
    });
  }

  calculateDailyNeeds(weight: number, height: number, age: number, gender: string, activityLevel: string): number {
    // Basic BMR calculation (Mifflin-St Jeor Equation)
    let bmr = 10 * weight + 6.25 * height - 5 * age;
    bmr = gender === 'male' ? bmr + 5 : bmr - 161;
    
    // Activity factor multiplication
    const activityFactors = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
      veryActive: 1.9
    };
    
    return Math.round(bmr * activityFactors[activityLevel] || activityFactors.moderate);
  }
}