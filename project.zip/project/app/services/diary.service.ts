import { DiaryEntry, DailyLog } from '../models/diary.model';
import { Observable } from '@nativescript/core';

export class DiaryService extends Observable {
  private static instance: DiaryService;
  private entries: Map<string, DiaryEntry[]>;

  private constructor() {
    super();
    this.entries = new Map();
  }

  static getInstance(): DiaryService {
    if (!DiaryService.instance) {
      DiaryService.instance = new DiaryService();
    }
    return DiaryService.instance;
  }

  addEntry(entry: DiaryEntry): void {
    const dateKey = this.getDateKey(entry.timestamp);
    const dayEntries = this.entries.get(dateKey) || [];
    dayEntries.push(entry);
    this.entries.set(dateKey, dayEntries);
    this.notifyPropertyChange('entries', this.entries);
  }

  getDailyLog(date: Date): DailyLog {
    const dateKey = this.getDateKey(date);
    const entries = this.entries.get(dateKey) || [];
    
    return {
      date: dateKey,
      entries,
      totalCalories: entries.reduce((sum, entry) => sum + entry.calories, 0),
      totalProtein: entries.reduce((sum, entry) => sum + entry.protein, 0),
      totalCarbs: entries.reduce((sum, entry) => sum + entry.carbs, 0),
      totalFat: entries.reduce((sum, entry) => sum + entry.fat, 0)
    };
  }

  private getDateKey(date: Date): string {
    return date.toISOString().split('T')[0];
  }
}