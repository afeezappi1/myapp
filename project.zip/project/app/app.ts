import { Application } from '@nativescript/core';
import { User } from './models/user.model';

// Initialize user singleton
User.getInstance();

Application.run({ moduleName: 'app-root' });