export interface UserProfile {
  name: string;
  age: number;
  gender: string;
  height: number;
  weight: number;
  goals: string[];
  dietaryPreferences: string[];
  allergies: string[];
}

export class User {
  private static instance: User;
  private _profile: UserProfile;

  private constructor() {
    this._profile = {
      name: '',
      age: 0,
      gender: '',
      height: 0,
      weight: 0,
      goals: [],
      dietaryPreferences: [],
      allergies: []
    };
  }

  static getInstance(): User {
    if (!User.instance) {
      User.instance = new User();
    }
    return User.instance;
  }

  get profile(): UserProfile {
    return this._profile;
  }

  updateProfile(profile: Partial<UserProfile>) {
    this._profile = { ...this._profile, ...profile };
  }
}