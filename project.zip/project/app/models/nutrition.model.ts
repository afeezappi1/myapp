export interface NutritionInfo {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  vitamins: { [key: string]: number };
  minerals: { [key: string]: number };
  allergens: string[];
}

export interface FoodItem {
  name: string;
  portion: string;
  nutrition: NutritionInfo;
  ingredients: string[];
  category: string;
}